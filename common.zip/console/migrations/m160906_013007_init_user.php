<?php

use yii\db\Migration;

class m160906_013007_init_user extends Migration
{
    public function up()
    {

    }

    public function down()
    {
        echo "m160906_013007_init_user cannot be reverted.\n";

        return false;
    }

    /*
    // Use safeUp/safeDown to run migration code within a transaction
    public function safeUp()
    {
    }

    public function safeDown()
    {
    }
    */
}
