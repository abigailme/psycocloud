<?php
return [
    'components' => [
        'db' => [
            'dsn' => 'mysql:host=localhost;dbname=yii2_advanced_tests',
            'username' => 'root',
            'password' => '',
            'charset' => 'utf8',
        ],
    ],
];
