<?php

namespace tests\codeception\backend\unit;

class TestCase extends \yii\codeception\TestCase
{
    public $appConfig = '@tests/codeception/config/backend/unit.php';
}
